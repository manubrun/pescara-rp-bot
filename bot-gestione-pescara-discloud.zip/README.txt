BOT GESTIONE PESCARA — DISCloud

1. Carica lo ZIP nella dashboard di Discloud.
2. Inserisci il valore del Bot Token nella variabile d'ambiente:
   DISCORD_TOKEN
3. Avvia o riavvia l'applicazione.

Non inserire il token in questo archivio o nei file del progetto.